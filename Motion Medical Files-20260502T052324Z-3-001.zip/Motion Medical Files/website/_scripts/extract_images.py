"""
Extract product hero shots from each Turkish brochure PDF.

Strategy v4 — keep the brochure background:
1. Render page at 300 DPI.
2. Get every text-block bounding box from PyMuPDF and paint each one
   in the brochure's background colour. This wipes titles, paragraphs,
   spec tables, footers - leaving only the product photography.
3. Build a mask of "non-background" pixels (pixels that differ from the
   sampled background by more than a small threshold). Erode + dilate
   to drop tiny stray marks.
4. Take the bounding box of that mask and crop the ORIGINAL bg-painted
   image to it. The pale-blue background is kept intact — it matches
   the brochure aesthetic and shows transparent / white devices clearly.
5. Save thumb (300w) and hero (1400w) JPGs (no transparency needed).
"""

import fitz, io, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageChops

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
PDF_DIR = ROOT / "Turkish brochures"
OUT_DIR = ROOT / "website" / "assets" / "products"
OUT_DIR.mkdir(parents=True, exist_ok=True)

DPI = 300
SCALE = DPI / 72.0

PRODUCTS = {
    "manifold.pdf":          ("manifold",               0),
    "manifold kit set.pdf":  ("manifold-kit-set",       0),
    "indeflatör 20 cc.pdf":  ("indeflator-20cc",        0),
    "İNDEFLATÖR 30 CC.pdf":  ("indeflator-30cc",        0),
    "koroner enjektör.pdf":  ("coronary-syringe",       0),
    "trans radial bant.pdf": ("trans-radial-band",      0),
    "KİFOPLASTİ.pdf":        ("kyphoplasty-indeflator", 0),
    "KEMİK ÇİMENTOSU.pdf":   ("bone-cement-mixer",      0),
    "cilt stapleri.pdf":     ("skin-stapler",           0),
}

def render_page(page, dpi=DPI) -> Image.Image:
    pix = page.get_pixmap(dpi=dpi, alpha=False)
    return Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")

def text_rects(page):
    rects = []
    for blk in page.get_text("blocks"):
        x0, y0, x1, y1, *_ = blk
        rects.append((int(x0*SCALE), int(y0*SCALE), int(x1*SCALE), int(y1*SCALE)))
    return rects

def sample_bg(img):
    w, h = img.size
    s = max(20, w//40)
    samples = []
    for cx, cy in [(0,0), (w-s,0), (0,h-s), (w-s,h-s)]:
        crop = img.crop((cx, cy, cx+s, cy+s))
        for r,g,b in crop.getdata():
            samples.append((r,g,b))
    n = len(samples)
    return (sum(p[0] for p in samples)//n,
            sum(p[1] for p in samples)//n,
            sum(p[2] for p in samples)//n)

def paint_text(img, rects, bg, pad=6):
    img = img.copy()
    draw = ImageDraw.Draw(img)
    w, h = img.size
    for x0,y0,x1,y1 in rects:
        draw.rectangle((max(0,x0-pad), max(0,y0-pad), min(w,x1+pad), min(h,y1+pad)), fill=bg)
    return img

def content_bbox(img, bg, diff_threshold=22):
    """
    Return the tight bbox of pixels that differ from the brochure
    background by more than `diff_threshold`. Erode/dilate to ignore noise.
    """
    bg_img = Image.new("RGB", img.size, bg)
    diff = ImageChops.difference(img, bg_img).convert("L")
    mask = diff.point(lambda v: 255 if v > diff_threshold else 0)
    # heavy erosion to wipe small decorative marks (page-top dots, callouts)
    eroded = mask.filter(ImageFilter.MinFilter(13))
    eroded = eroded.filter(ImageFilter.MinFilter(11))
    dilated = eroded.filter(ImageFilter.MaxFilter(25))
    bbox = dilated.getbbox()
    return bbox

def process(pdf_path, slug, page_idx):
    print(f"Processing {pdf_path.name} -> {slug}")
    doc = fitz.open(pdf_path)
    page = doc[page_idx]
    img = render_page(page)
    rects = text_rects(page)
    bg = sample_bg(img)
    print(f"  bg sample: rgb{bg}  text blocks: {len(rects)}")

    cleaned = paint_text(img, rects, bg)
    bbox = content_bbox(cleaned, bg)
    if not bbox:
        print("  no content bbox found; skipping")
        return

    pad = 60
    w, h = cleaned.size
    x0, y0, x1, y1 = bbox
    crop_box = (max(0, x0-pad), max(0, y0-pad), min(w, x1+pad), min(h, y1+pad))
    final = cleaned.crop(crop_box)

    hero = final.copy()
    if hero.width > 1400:
        hero.thumbnail((1400, 1400), Image.LANCZOS)
    hero.save(OUT_DIR / f"{slug}.jpg", "JPEG", quality=88, optimize=True)

    thumb = final.copy()
    thumb.thumbnail((360, 360), Image.LANCZOS)
    thumb.save(OUT_DIR / f"{slug}-thumb.jpg", "JPEG", quality=85, optimize=True)

    print(f"  hero: {hero.size}  thumb: {thumb.size}")
    doc.close()

def main():
    # remove old PNG outputs to avoid confusion
    for old in OUT_DIR.glob("*.png"):
        old.unlink()
    for pdf_name, (slug, page_idx) in PRODUCTS.items():
        pdf_path = PDF_DIR / pdf_name
        if not pdf_path.exists():
            print(f"MISSING: {pdf_path}")
            continue
        try:
            process(pdf_path, slug, page_idx)
        except Exception as e:
            print(f"  ERROR: {e}")

if __name__ == "__main__":
    main()
