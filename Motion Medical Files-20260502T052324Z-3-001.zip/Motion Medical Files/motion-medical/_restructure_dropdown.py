#!/usr/bin/env python3
"""One-shot: swap the flat mega-dropdown for a categorized layout across all 14 HTML files."""
import re, glob, sys

def new_grid(p):
    """p = '' for top-level pages, '../' for products/* subpages."""
    return f'''<div class="products-grid">
          <div class="dropdown-pillar">
            <div class="pillar-heading">Interventional Access</div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Fluid Management</div>
              <a class="product-card" href="{p}products/manifold.html">
                <span class="thumb"><img src="{p}assets/products/manifold.png" alt="Manifold"></span>
                <span class="info"><span class="name">Manifold</span></span>
              </a>
              <a class="product-card" href="{p}products/manifold-kit-set.html">
                <span class="thumb"><img src="{p}assets/products/manifold_kit_set.png" alt="Manifold Kit Set"></span>
                <span class="info"><span class="name">Manifold Kit Set</span></span>
              </a>
              <a class="product-card" href="{p}products/coronary-injector.html">
                <span class="thumb"><img src="{p}assets/products/coronary_injector.png" alt="Coronary Injector"></span>
                <span class="info"><span class="name">Coronary Injector</span></span>
              </a>
            </div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Inflation Systems</div>
              <a class="product-card" href="{p}products/indeflator-20cc.html">
                <span class="thumb"><img src="{p}assets/products/indeflator_20cc.png" alt="Inflator 20 cc"></span>
                <span class="info"><span class="name">Inflator 20 cc</span></span>
              </a>
              <a class="product-card" href="{p}products/indeflator-30cc.html">
                <span class="thumb"><img src="{p}assets/products/indeflator_30cc.png" alt="Inflator 30 cc"></span>
                <span class="info"><span class="name">Inflator 30 cc</span></span>
              </a>
            </div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Hemostasis</div>
              <a class="product-card" href="{p}products/trans-radial-band.html">
                <span class="thumb"><img src="{p}assets/products/trans_radial_band.png" alt="Trans Radial Band"></span>
                <span class="info"><span class="name">Trans Radial Band</span></span>
              </a>
            </div>
          </div>
          <div class="dropdown-pillar">
            <div class="pillar-heading">Vertebral Augmentation</div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Kyphoplasty</div>
              <a class="product-card" href="{p}products/kyphoplasty-inflator.html">
                <span class="thumb"><img src="{p}assets/products/kyphoplasty.png" alt="Kyphoplasty Inflator"></span>
                <span class="info"><span class="name">Kyphoplasty Inflator</span></span>
              </a>
            </div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Bone Management</div>
              <a class="product-card" href="{p}products/bone-cement-mixer.html">
                <span class="thumb"><img src="{p}assets/products/bone_cement.png" alt="Bone Cement Delivery System"></span>
                <span class="info"><span class="name">Bone Cement Delivery</span></span>
              </a>
            </div>
          </div>
          <div class="dropdown-pillar">
            <div class="pillar-heading">Surgical Closure</div>
            <div class="dropdown-subfamily">
              <div class="subfamily-heading">Wound Closure</div>
              <a class="product-card" href="{p}products/skin-stapler.html">
                <span class="thumb"><img src="{p}assets/products/skin_stapler.png" alt="Skin Stapler"></span>
                <span class="info"><span class="name">Skin Stapler</span></span>
              </a>
            </div>
          </div>
          </div>'''

# Match from <div class="products-grid"> up to (but not including) <div class="dropdown-footer">
# Uses DOTALL so .*? spans newlines; non-greedy so we stop at the first dropdown-footer.
pattern = re.compile(r'<div class="products-grid">.*?(?=<div class="dropdown-footer">)', re.DOTALL)

def process(path, prefix):
    with open(path, encoding='utf-8') as f:
        content = f.read()
    replacement = new_grid(prefix) + '\n          '
    new_content, n = pattern.subn(replacement, content)
    if n == 0:
        print(f'  SKIP {path} — no mega-dropdown found')
        return
    with open(path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    print(f'  OK   {path} ({n} block replaced)')

print('Top-level pages:')
for p in ['index.html', 'products.html', 'procedure-packs.html', 'quality.html', 'contact.html']:
    process(p, '')

print('Product subpages:')
for p in sorted(glob.glob('products/*.html')):
    process(p, '../')
